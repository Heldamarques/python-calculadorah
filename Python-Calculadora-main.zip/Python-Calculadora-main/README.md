# Python-Calculadora
 Calculadora desenvolvida em Python como parte de um projeto interdisciplinar. Este projeto tem como foco a implementação de operações de conversão numérica entre diferentes bases, como a conversão de decimal para binário, hexadecimal e octal, bem como a conversão de binário, hexadecimal e octal para decimal.
